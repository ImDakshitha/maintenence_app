package com.dakodelabs.maintenance_app.entity;

public enum RequestType {
    WORK_REQUEST,
    MAINTENANCE_WORK_REQUEST
} 