package com.dakodelabs.maintenance_app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MaintenanceAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
